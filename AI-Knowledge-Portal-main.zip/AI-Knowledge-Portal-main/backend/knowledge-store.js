const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const segmenter = new Intl.Segmenter('th', { granularity: 'word' });

function tokenize(text) {
    return [...segmenter.segment(text.toLocaleLowerCase('th'))]
        .filter((part) => part.isWordLike)
        .map((part) => part.segment);
}

function makeExcerpt(content, terms, maxLength = 4000) {
    const text = content.trim();
    const lowerText = text.toLocaleLowerCase('th');
    const matches = terms
        .map((term) => lowerText.indexOf(term.toLocaleLowerCase('th')))
        .filter((index) => index >= 0);

    if (text.length <= maxLength || matches.length === 0) {
        return text.slice(0, maxLength);
    }

    const start = Math.max(0, Math.min(...matches) - 400);
    return text.slice(start, start + maxLength);
}

function createKnowledgeStore(databasePath) {
    fs.mkdirSync(path.dirname(databasePath), { recursive: true });

    const database = new Database(databasePath);
    database.pragma('journal_mode = WAL');
    database.pragma('foreign_keys = ON');
    database.exec(`
        CREATE TABLE IF NOT EXISTS knowledge_documents (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    `);
    database.exec(`
        CREATE TABLE IF NOT EXISTS question_analytics (
            id TEXT PRIMARY KEY,
            category TEXT NOT NULL,
            outcome TEXT NOT NULL,
            citation_count INTEGER NOT NULL,
            duration_ms INTEGER NOT NULL,
            created_at TEXT NOT NULL
        )
    `);
    database.exec(`
        CREATE TABLE IF NOT EXISTS question_history (
            id TEXT PRIMARY KEY,
            answer_id TEXT,
            question_text TEXT NOT NULL,
            answer_text TEXT,
            category TEXT NOT NULL,
            outcome TEXT NOT NULL,
            duration_ms INTEGER NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS question_citations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id TEXT NOT NULL REFERENCES question_history(id) ON DELETE CASCADE,
            document_id TEXT NOT NULL,
            title TEXT NOT NULL,
            category TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS question_feedback (
            question_id TEXT PRIMARY KEY REFERENCES question_history(id) ON DELETE CASCADE,
            rating TEXT NOT NULL CHECK (rating IN ('up', 'down')),
            comment TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
    `);

    const insertDocument = database.prepare(`
        INSERT INTO knowledge_documents (id, title, category, content, created_at)
        VALUES (@id, @title, @category, @content, @created_at)
    `);
    const listDocuments = database.prepare(`
        SELECT id, title, category, created_at
        FROM knowledge_documents
        ORDER BY created_at DESC
    `);
    const getDocuments = database.prepare(`
        SELECT id, title, category, content, created_at
        FROM knowledge_documents
    `);
    const deleteDocument = database.prepare(
        'DELETE FROM knowledge_documents WHERE id = ?'
    );
    const insertQuestionAnalytics = database.prepare(`
        INSERT INTO question_analytics
            (id, category, outcome, citation_count, duration_ms, created_at)
        VALUES
            (@id, @category, @outcome, @citation_count, @duration_ms, @created_at)
    `);
    const insertQuestionHistory = database.prepare(`
        INSERT INTO question_history
            (id, answer_id, question_text, answer_text, category, outcome, duration_ms, created_at)
        VALUES
            (@id, @answer_id, @question_text, @answer_text, @category, @outcome, @duration_ms, @created_at)
    `);
    const insertQuestionCitation = database.prepare(`
        INSERT INTO question_citations (question_id, document_id, title, category)
        VALUES (@question_id, @document_id, @title, @category)
    `);
    const recordQuestionTransaction = database.transaction((record) => {
        insertQuestionHistory.run(record);
        for (const citation of record.citations) {
            insertQuestionCitation.run({
                question_id: record.id,
                document_id: citation.id,
                title: citation.title,
                category: citation.category,
            });
        }
        insertQuestionAnalytics.run({
            id: crypto.randomUUID(),
            category: record.category,
            outcome: record.outcome,
            citation_count: record.citations.length,
            duration_ms: record.duration_ms,
            created_at: record.created_at,
        });
    });
    const getQuestionHistory = database.prepare(`
        SELECT id, answer_id, question_text, answer_text, category, outcome, duration_ms, created_at
        FROM question_history
        ORDER BY created_at DESC, rowid DESC
        LIMIT ?
    `);
    const getQuestionCitations = database.prepare(`
        SELECT document_id, title, category
        FROM question_citations
        WHERE question_id = ?
        ORDER BY id
    `);
    const getQuestionFeedback = database.prepare(`
        SELECT rating, comment, created_at, updated_at
        FROM question_feedback
        WHERE question_id = ?
    `);
    const getQuestionWithAnswer = database.prepare(`
        SELECT id FROM question_history WHERE id = ? AND answer_text IS NOT NULL
    `);
    const saveQuestionFeedback = database.prepare(`
        INSERT INTO question_feedback (question_id, rating, comment, created_at, updated_at)
        VALUES (@question_id, @rating, @comment, @created_at, @updated_at)
        ON CONFLICT(question_id) DO UPDATE SET
            rating = excluded.rating,
            comment = excluded.comment,
            updated_at = excluded.updated_at
    `);
    const getQuestionTotals = database.prepare(`
        SELECT
            COUNT(*) AS questions,
            SUM(CASE WHEN outcome = 'answered' THEN 1 ELSE 0 END) AS answered,
            SUM(CASE WHEN outcome = 'no_documents' THEN 1 ELSE 0 END) AS no_documents,
            SUM(CASE WHEN outcome IN ('ai_not_configured', 'ai_empty', 'ai_error', 'ai_timeout')
                THEN 1 ELSE 0 END) AS failed,
            AVG(CASE WHEN outcome = 'answered' THEN duration_ms END) AS average_answer_ms
        FROM question_analytics
    `);
    const getDailyQuestionCounts = database.prepare(`
        SELECT
            substr(created_at, 1, 10) AS date,
            COUNT(*) AS questions,
            SUM(CASE WHEN outcome = 'answered' THEN 1 ELSE 0 END) AS answered
        FROM question_analytics
        WHERE created_at >= @start AND created_at < @end
        GROUP BY substr(created_at, 1, 10)
    `);
    const getCategoryCounts = database.prepare(`
        SELECT category, COUNT(*) AS questions
        FROM question_analytics
        GROUP BY category
        ORDER BY questions DESC, category ASC
    `);
    const getRecentQuestions = database.prepare(`
        SELECT category, outcome, citation_count, duration_ms, created_at
        FROM question_analytics
        ORDER BY created_at DESC
        LIMIT 10
    `);
    const getDocumentCount = database.prepare(
        'SELECT COUNT(*) AS count FROM knowledge_documents'
    );

    return {
        addDocument({ title, category, content }) {
            const document = {
                id: crypto.randomUUID(),
                title,
                category,
                content,
                created_at: new Date().toISOString(),
            };
            insertDocument.run(document);
            return {
                id: document.id,
                title: document.title,
                category: document.category,
                created_at: document.created_at,
            };
        },

        listDocuments() {
            return listDocuments.all();
        },

        deleteDocument(id) {
            return deleteDocument.run(id).changes > 0;
        },

        recordQuestion({
            id = crypto.randomUUID(),
            answerId = null,
            questionText,
            answerText = null,
            citations = [],
            category,
            outcome,
            durationMs = 0,
        }) {
            const record = {
                id,
                answer_id: answerId,
                question_text: questionText,
                answer_text: answerText,
                category,
                outcome,
                duration_ms: durationMs,
                created_at: new Date().toISOString(),
                citations,
            };
            recordQuestionTransaction(record);
            return id;
        },

        getQuestionHistory(limit = 50) {
            const safeLimit = Math.max(1, Math.min(100, Math.floor(limit)));
            return getQuestionHistory.all(safeLimit).map((question) => ({
                ...question,
                citations: getQuestionCitations.all(question.id),
                feedback: getQuestionFeedback.get(question.id) || null,
            }));
        },

        saveFeedback(questionId, rating, comment) {
            if (!getQuestionWithAnswer.get(questionId)) return false;
            const now = new Date().toISOString();
            saveQuestionFeedback.run({
                question_id: questionId,
                rating,
                comment,
                created_at: now,
                updated_at: now,
            });
            return true;
        },

        getAnalytics() {
            const end = new Date();
            end.setUTCHours(0, 0, 0, 0);
            end.setUTCDate(end.getUTCDate() + 1);
            const start = new Date(end);
            start.setUTCDate(start.getUTCDate() - 7);
            const startDate = start.toISOString().slice(0, 10);
            const endDate = end.toISOString().slice(0, 10);
            const dailyCounts = new Map(
                getDailyQuestionCounts.all({
                    start: `${startDate}T00:00:00.000Z`,
                    end: `${endDate}T00:00:00.000Z`,
                }).map((row) => [row.date, row])
            );
            const days = Array.from({ length: 7 }, (_, index) => {
                const date = new Date(start);
                date.setUTCDate(date.getUTCDate() + index);
                const key = date.toISOString().slice(0, 10);
                const row = dailyCounts.get(key);
                return {
                    date: key,
                    questions: Number(row?.questions || 0),
                    answered: Number(row?.answered || 0),
                };
            });
            const totals = getQuestionTotals.get();

            return {
                totals: {
                    questions: Number(totals.questions || 0),
                    answered: Number(totals.answered || 0),
                    noDocuments: Number(totals.no_documents || 0),
                    failed: Number(totals.failed || 0),
                    averageAnswerMs: Math.round(Number(totals.average_answer_ms || 0)),
                    documents: getDocumentCount.get().count,
                },
                daily: days,
                categories: getCategoryCounts.all().map((row) => ({
                    category: row.category,
                    questions: row.questions,
                })),
                recent: getRecentQuestions.all(),
            };
        },

        searchDocuments(query, category, limit = 5) {
            const terms = [...new Set(tokenize(query))];
            if (terms.length === 0) return [];

            return getDocuments.all()
                .filter((document) => !category || document.category === category)
                .map((document) => {
                    const searchableText = `${document.title}\n${document.category}\n${document.content}`;
                    const documentTerms = new Set(tokenize(searchableText));
                    const matchingTerms = terms.filter((term) => documentTerms.has(term));
                    const containsPhrase = searchableText
                        .toLocaleLowerCase('th')
                        .includes(query.toLocaleLowerCase('th'));

                    return {
                        ...document,
                        score: matchingTerms.length + (containsPhrase ? 2 : 0),
                    };
                })
                .filter((document) => document.score > 0)
                .sort((a, b) => b.score - a.score || b.created_at.localeCompare(a.created_at))
                .slice(0, limit)
                .map(({ score, ...document }) => ({
                    ...document,
                    content: makeExcerpt(document.content, terms),
                }));
        },

        close() {
            database.close();
        },
    };
}

module.exports = { createKnowledgeStore };
