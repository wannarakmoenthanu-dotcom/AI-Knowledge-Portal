const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');
const { createKnowledgeStore } = require('../knowledge-store');

test('stores, searches, filters, and deletes knowledge documents', (t) => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'knowledge-store-'));
    const store = createKnowledgeStore(path.join(directory, 'knowledge.sqlite'));

    t.after(() => {
        store.close();
        fs.rmSync(directory, { recursive: true, force: true });
    });

    const holiday = store.addDocument({
        title: 'วันหยุดประจำปี',
        category: 'HR & สวัสดิการ',
        content: 'วันหยุดปีใหม่ขององค์กรคือวันที่ 1 มกราคม',
    });
    store.addDocument({
        title: 'ค่าเดินทาง',
        category: 'การเงิน & เบิกจ่าย',
        content: 'พนักงานสามารถเบิกค่าเดินทางได้ตามเงื่อนไขที่กำหนด',
    });

    assert.equal(store.listDocuments().length, 2);
    assert.equal(
        store.searchDocuments('วันหยุดปีใหม่', 'HR & สวัสดิการ')[0].id,
        holiday.id
    );
    assert.deepEqual(store.searchDocuments('วันหยุดปีใหม่', 'การเงิน & เบิกจ่าย'), []);
    const questionId = store.recordQuestion({
        id: 'question-answer-1',
        answerId: 'answer-1',
        questionText: 'วันลาพักร้อนทดสอบมีกี่วัน',
        answerText: 'ตัวอย่างเอกสารระบุ 12 วัน',
        citations: [{ id: holiday.id, title: holiday.title, category: holiday.category }],
        category: 'HR & สวัสดิการ',
        outcome: 'answered',
        durationMs: 120,
    });
    store.recordQuestion({
        id: 'question-no-docs-1',
        questionText: 'คำถามที่ไม่มีเอกสาร',
        answerText: 'ยังไม่พบเอกสารที่เกี่ยวข้อง',
        category: 'เอกสารทั้งหมด',
        outcome: 'no_documents',
        durationMs: 5,
    });
    assert.equal(store.saveFeedback(questionId, 'up', 'คำตอบเข้าใจง่าย'), true);
    assert.equal(store.saveFeedback(questionId, 'down', 'ขอรายละเอียดเพิ่ม'), true);
    assert.equal(store.saveFeedback('missing-question', 'up', ''), false);

    const history = store.getQuestionHistory();
    assert.equal(history.length, 2);
    assert.equal(history[0].question_text, 'คำถามที่ไม่มีเอกสาร');
    assert.equal(history[1].answer_id, 'answer-1');
    assert.equal(history[1].citations[0].title, holiday.title);
    assert.equal(history[1].feedback.rating, 'down');
    assert.equal(history[1].feedback.comment, 'ขอรายละเอียดเพิ่ม');

    const analytics = store.getAnalytics();
    assert.equal(analytics.totals.questions, 2);
    assert.equal(analytics.totals.answered, 1);
    assert.equal(analytics.totals.noDocuments, 1);
    assert.equal(analytics.totals.documents, 2);
    assert.equal(analytics.daily.length, 7);
    assert.equal(analytics.recent.length, 2);
    assert.equal('question_text' in analytics.recent[0], false);
    assert.equal(store.deleteDocument(holiday.id), true);
    assert.equal(store.deleteDocument(holiday.id), false);
});
